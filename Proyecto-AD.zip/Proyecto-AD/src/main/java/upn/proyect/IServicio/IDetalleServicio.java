package upn.proyect.IServicio;

public interface IDetalleServicio {

}
