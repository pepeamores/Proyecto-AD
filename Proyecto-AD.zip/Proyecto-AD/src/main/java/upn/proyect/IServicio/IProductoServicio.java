package upn.proyect.IServicio;

public interface IProductoServicio {

}
