package upn.proyect.IServicio;

import java.util.Optional;

import upn.proyect.entidades.Carrito;




public interface ICarritoServicio {
	
	public Carrito buscarProducto(int Idproducto);
}
